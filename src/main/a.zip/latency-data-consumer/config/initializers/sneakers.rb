Sneakers.configure({})
Sneakers.logger.level = Logger::INFO # the default DEBUG is too noisy
